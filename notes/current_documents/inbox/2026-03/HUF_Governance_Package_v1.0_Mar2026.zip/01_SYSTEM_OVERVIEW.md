HUF-DOC: HUF.REL.ORG.NOTE.DOC_LIBRARY_SYSTEM | HUF:1.2.0 | DOC:v1.0.0 | STATUS:release | LANE:REL | RO:Peter Higgins
CODES: ORG, LIBRARY, GOVERNANCE | ART: CM, AS, TR, EB | EVID:E1 | POSTURE:OP | WEIGHTS: OP=0.80 TOOL=0.20 PEER=0.00 | CAP: OP_MIN=0.51 TOOL_MAX=0.49 | CANON:01_SYSTEM_OVERVIEW.md

# HUF Document Coding + Library Management System
## "HUF Document 1" — The system that explains itself
*Human/machine-readable governance · HUF v1.2.0 · 2026-03-01*

This document is the self-describing entry point for the HUF library. It explains the
coding system embedded in every document's header — a system designed so that any reader
(human or AI) can determine a document's identity, status, canonical path, evidence level,
and operator-control posture from the first two lines alone.

---

## The two failure modes this system prevents

**1. Name collisions**
Multiple agents producing "primer.md", "taxonomy.md", "exhibit.docx" with the same filenames.
Result: two files compete for canonical status; neither can be trusted.

**2. Silent overwrites**
A new version replaces an old one without a supersession chain.
Result: the old version disappears silently; the governance record has a gap.

HUF principle applied to documentation:
> **Nothing disappears silently.**
Every document that matters is identifiable, inventory-listed, and traceable across versions.

---

## A) Document IDs — stable identities

Every document MUST have a stable Doc ID assigned at staging. The ID never changes,
even if the filename changes.

### Format
`HUF.<LANE>.<DOMAIN>.<TYPE>.<SLUG>`

| Field | Values | Meaning |
|-------|--------|---------|
| LANE | DRAFT, REL, LEGACY | Publication stage |
| DOMAIN | ORG, LRN, BOOK, CASE, PARTNER, WIKI | Subject area |
| TYPE | POLICY, INDEX, MODULE, PRIMER, EXHIBIT, NOTE, TEMPLATE, TRACE, CONTRACT | Document function |
| SLUG | UPPERCASE_UNDERSCORES | Stable short name |

### Examples
- `HUF.REL.ORG.POLICY.DOC_GOVERNANCE` — the governance rules document
- `HUF.REL.LRN.MODULE.00_ORIENTATION` — first orientation module
- `HUF.DRAFT.PARTNER.PRIMER.RAMSAR_V12` — Ramsar contact primer draft
- `HUF.REL.CASE.EXHIBIT.D1_SOURDOUGH_CROATIA` — cross-domain case study exhibit

---

## B) Two-line header — self-describing documents

Every document MUST begin with exactly these two lines.
For DOCX/PDF: place as the first block on page 1.
For Markdown: place at the very top of the file.

### Line 1 — Identity
```
HUF-DOC: <DOC_ID> | HUF:<HUF_VERSION> | DOC:<DOC_VERSION> | STATUS:<status> | LANE:<lane> | RO:<responsible_operator>
```

### Line 2 — Posture
```
CODES: <tags> | ART: CM, AS, TR, EB | EVID:E0-E4 | POSTURE: DEF/OP/INT/THM | WEIGHTS: OP=.. TOOL=.. PEER=.. | CAP: OP_MIN=0.51 TOOL_MAX=0.49 | CANON:<canonical_path>
```

### Field definitions

**Line 1 fields**
- `HUF-DOC` — the stable Doc ID (never changes)
- `HUF` — framework version assumed by this document
- `DOC` — document revision (increment on substantive change)
- `STATUS` — draft / reviewed / release / deprecated
- `LANE` — DRAFT / REL / LEGACY
- `RO` — Responsible Operator (named human; required)

**Line 2 fields**
- `CODES` — subject tags (free, multi-value)
- `ART` — artifact types present: CM (Coherence Map), AS (Active Set), TR (Trace Report), EB (Error Budget)
- `EVID` — evidence level: E0 narrative · E1 artifacts · E2 reproducible run · E3 empirical eval · E4 formal proof
- `POSTURE` — DEF (definition) · OP (operational) · INT (interpretive) · THM (theorem/proof)
- `WEIGHTS` — declared review weights (must sum to 1.0; OP must be ≥ 0.51)
- `CAP` — hard constraint declaration (OP_MIN=0.51 TOOL_MAX=0.49 — these values are invariant)
- `CANON` — canonical file path (the stable home of this document)

### Complete example
```
HUF-DOC: HUF.DRAFT.PARTNER.PRIMER.RAMSAR_V12 | HUF:1.2.0 | DOC:v12.0 | STATUS:draft | LANE:DRAFT | RO:Peter Higgins
CODES: PARTNER, RAMSAR, ECOLOGY | ART: CM, TR | EVID:E1 | POSTURE:OP | WEIGHTS: OP=0.80 TOOL=0.20 PEER=0.00 | CAP: OP_MIN=0.51 TOOL_MAX=0.49 | CANON:notes/current_documents/staged/HUF.DRAFT.PARTNER.PRIMER.RAMSAR_V12/ramsar_contact_primer_v12.docx
```

---

## C) Lane system — media flow

### Lane INBOX (uncontrolled intake)
- Location: `notes/current_documents/inbox/YYYY-MM/`
- Raw dumps, duplicates, messy filenames are all accepted
- NOT allowed to claim canonical status
- Any document without a two-line header is treated as INBOX

### Lane STAGED (assigned ID, under review)
- Location: `notes/current_documents/staged/<DOC_ID>/`
- Requirements: two-line header · Doc ID · manifest entry · supersedes chain declared
- Status: draft or reviewed

### Lane RELEASE (canonical, stable)
- Locations:
  - `docs/learning/` (Markdown only — learning modules)
  - `docs/books/` (Markdown only — handbook and math volumes)
  - `cases/<case_name>/` (case studies; DOCX allowed)
  - `notes/_org/` (governance files only)
- Requirements: status = reviewed or release · human approval

### Lane LEGACY (preserved trail)
- Location: `notes/legacy/`
- All superseded documents are here, never deleted
- Must carry `superseded_by` pointer in manifest

---

## D) Status values — comprehension gate

| Status | Meaning | Release allowed? |
|--------|---------|-----------------|
| draft | Active iteration; may change structurally | No |
| reviewed | Stable structure (48h no change) + header + manifest entry | Not yet |
| release | Human-approved; canonical path locked | Yes |
| deprecated | Superseded; retained in legacy trail | N/A |

---

## E) Artifact codes (locked)

| Code | Full name | What it contains |
|------|-----------|-----------------|
| CM | Coherence Map | Portfolio share table, PROOF line, leverage values |
| AS | Active Set | Current declared elements and their weights |
| TR | Trace Report | Change log: intentional vs. silent drift, per cycle |
| EB | Error Budget | MDG, threshold config, orphan alert status |

---

## F) Evidence levels (E0–E4)

| Level | Name | What qualifies |
|-------|------|---------------|
| E0 | Narrative | Claims without supporting artifacts |
| E1 | Artifact evidence | CM/AS/TR/EB outputs present and internally consistent |
| E2 | Reproducible run | Code + inputs → verified outputs; can be re-run |
| E3 | Empirical evaluation | Real dataset, documented method, reproducible result |
| E4 | Formal proof | Explicit assumptions + complete proof within stated scope |

---

## G) Posture codes

| Code | Meaning |
|------|---------|
| DEF | Definitional — introduces a term or classification |
| OP | Operational — describes how to do something |
| INT | Interpretive — structural analogy; not domain equivalence claim |
| THM | Theorem/proof — formal claim with stated assumptions |

**Scope discipline:** prefer INT over THM unless proof is complete.
Prefer "structural invariance (interpretive)" over "domain-invariant" until formal proof assumptions are explicit.

---

## H) Supersession rule — nothing disappears silently

When Document B replaces Document A:

Document B must declare:
```json
"supersedes": ["HUF.LEGACY.PARTNER.PRIMER.RAMSAR_V11"]
```

Document A must be updated to:
```json
"status": "deprecated",
"superseded_by": "HUF.DRAFT.PARTNER.PRIMER.RAMSAR_V12"
```

Document A moves to `notes/legacy/` but is NEVER deleted.
The manifest retains both entries permanently.

---

## I) Machine-readable core files

| File | Role |
|------|------|
| `notes/_org/doc_manifest.json` | Inventory of all documents: ID, path, status, weights, supersedes chain |
| `notes/_org/sitemap.json` | Human navigation map: volumes, lanes, learning levels |
| `notes/_org/doc_id_registry.json` | Registry of issued IDs and format definitions |

---

*Peter Higgins · Rogue Wave Audio · Markham, Ontario*
*HUF v1.2.0 · MIT License · 2026-03-01*
*Contributors: Claude, ChatGPT, Grok, Gemini, Copilot*
