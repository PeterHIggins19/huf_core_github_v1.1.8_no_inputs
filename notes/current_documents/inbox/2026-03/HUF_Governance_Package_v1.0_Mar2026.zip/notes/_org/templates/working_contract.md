# HUF Working Contract
*Template — fill in all fields before use*

---
Contract ID:        HUF.REL.ORG.CONTRACT.<SLUG>
HUF Version:        <version>
Date:               <date>

PARTIES
Responsible Operator (RO):  <full name> · <organization> · <location>
Tools (collective):         <list of AI tools contributing to this workflow>

SCOPE
<Brief description of what this contract governs>

DECLARED WEIGHTS (readiness review)
w_OP   = <value, must be >= 0.51>
w_TOOL = <value, must be <= 0.49>
w_PEER = <value>
TOTAL  = 1.00  (must equal 1.00)

HARD CAPS (invariant)
OP_MIN   = 0.51
TOOL_MAX = 0.49

READINESS SCORING FORMULA
R = w_OP · R_OP + w_TOOL · R_TOOL + w_PEER · R_PEER
Release threshold: R >= <threshold, suggested 0.80>

RELEASE GATE (human-only — not subject to weighting)
Release / publish / send / commit requires explicit operator approval.
No automated publication. No AI-initiated dispatch.

COMPLIANCE CHECKS (required per document)
[ ] Weights declared in header (WEIGHTS field)
[ ] Caps satisfied (OP >= 0.51, TOOL <= 0.49)
[ ] RO named (RO field in line 1)
[ ] Supersession chain present (if replacing prior document)
[ ] Trace record attached or referenced

NON-COMPLIANCE CONSEQUENCE
Document remains in STAGED lane until all checks pass.

MATURITY LEVEL
[ ] Beginner (OP=0.80, TOOL=0.20) — first deployment
[ ] Standard team (OP=0.65, TOOL=0.20, PEER=0.15)
[ ] Mature experimental (OP=0.51, TOOL=0.49) — explicit opt-in, 3+ traced cycles required

UPGRADE CONDITIONS (to move to lower OP weight)
[ ] >= 3 completed cycles with trace records
[ ] No uncorrected silent drift in last 3 cycles
[ ] Explicit operator declaration in governance log
---
