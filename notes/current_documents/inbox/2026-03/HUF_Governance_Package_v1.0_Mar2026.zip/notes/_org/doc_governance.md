HUF-DOC: HUF.REL.ORG.POLICY.DOC_GOVERNANCE | HUF:1.2.0 | DOC:v2.0.0 | STATUS:release | LANE:REL | RO:Peter Higgins
CODES: ORG, GOVERNANCE | ART: CM, AS, TR, EB | EVID:E1 | POSTURE:OP | WEIGHTS: OP=0.80 TOOL=0.20 PEER=0.00 | CAP: OP_MIN=0.51 TOOL_MAX=0.49 | CANON:notes/_org/doc_governance.md

# HUF Document Governance
*Complete rules — 2026-03-01*

HUF principle applied to documentation:
> **Nothing disappears silently. The operator remains in command.**

---

## Rule 1 — Doc IDs (stable identities)
Format: `HUF.<LANE>.<DOMAIN>.<TYPE>.<SLUG>`
Never changes once assigned. Survives filename changes.

## Rule 2 — Two-line header (required)
All documents must carry the two-line header (see 01_SYSTEM_OVERVIEW.md for full field definitions).
Documents without it are INBOX and not canonical.

## Rule 3 — Lane discipline
INBOX → STAGED → RELEASE → LEGACY. No skipping STAGED.

## Rule 4 — Status gate
draft → reviewed → release. Reviewed = 48h stable + header + manifest entry.
Release = human-only approval gate.

## Rule 5 — Artifact codes (locked)
CM / AS / TR / EB. No synonyms in release-lane documents.

## Rule 6 — Evidence levels (E0–E4)
Declare evidence level in header. Do not overstate.

## Rule 7 — Operator Control Contract (HUF-51/49)
OP >= 0.51 always. TOOL <= 0.49 always. Release gate human-only always.
See 02_OPERATOR_CONTROL_CONTRACT.md for full specification.

## Rule 8 — Supersession (no silent replacement)
Superseding document declares supersedes chain.
Superseded document marked deprecated + superseded_by.
Moved to `notes/legacy/`. Never deleted.

## Rule 9 — Conservative posture discipline
Prefer "structural invariance (interpretive)" over "domain-invariant".
Reserve "theorem" for results with explicit assumptions + complete proof.
Label conjectures with [CONJECTURE] or [CONJECTURAL].

## Rule 10 — Named Responsible Operator (required)
Every document must name an RO. If no RO is named, it is INBOX.
