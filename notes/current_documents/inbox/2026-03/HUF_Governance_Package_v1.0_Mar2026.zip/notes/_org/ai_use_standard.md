HUF-DOC: HUF.REL.ORG.NOTE.AI_USE_STANDARD | HUF:1.2.0 | DOC:v2.0.0 | STATUS:release | LANE:REL | RO:Peter Higgins
CODES: ORG, AI_DISCLOSURE, SAFETY | ART: TR, EB | EVID:E0 | POSTURE:OP | WEIGHTS: OP=0.80 TOOL=0.20 PEER=0.00 | CAP: OP_MIN=0.51 TOOL_MAX=0.49 | CANON:notes/_org/ai_use_standard.md

# HUF AI Use Standard
*One-page insert — human-in-command posture — 2026-03-01*

## Principle
AI output is advisory. No release without human approval.
The tool must never control the operator. (See 02_OPERATOR_CONTROL_CONTRACT.md)

## Declared weights (required in every document header)
All weights must sum to 1.0.
- OP (Responsible Operator) — human reviewer
- TOOL (AI/tools) — collective contributions
- PEER (human peers) — if present

Hard cap (invariant):
- OP >= 0.51
- TOOL <= 0.49

## What weights control
Weights apply to draft readiness scoring only.
Release / publish / send / merge / commit is ALWAYS human-only.

## Recommended starting weight: OP=0.80 TOOL=0.20
New operators start here. Movement to lower OP requires explicit declaration + 3+ completed cycles.

## Minimal disclosure line (required on all externally distributed documents)
> AI-assisted drafting/editing may be used for clarity; the Responsible Operator reviewed
> and curated final content. Formal claims are conservative and supported by reproducible
> artifacts where stated. Claims should be treated as hypotheses unless supported by
> reproducible artifacts or formal proofs.

## Contributor credit
All AI systems contributing substantive content to a document should be listed under
`contributors` in the manifest. Credit is recorded, not hidden.
