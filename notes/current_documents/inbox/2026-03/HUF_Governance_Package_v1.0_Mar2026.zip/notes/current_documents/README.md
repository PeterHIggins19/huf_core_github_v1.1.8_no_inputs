# Current Documents — Draft Lane

This directory is the intake and staging area for all new documents.

## Workflow
INBOX (raw drop) → STAGED (ID + header) → RELEASE (human approval) → LEGACY (if superseded)

## Rule
Any file without a two-line HUF header is INBOX. INBOX files cannot claim canonical status.

## Directory structure
- `inbox/YYYY-MM/` — raw intake by month
- `staged/<DOC_ID>/` — files with assigned IDs under review
