# HUF Governance Package — Complete Onboarding Bundle
**Version:** v1.0 · **Generated:** 2026-03-01
**Owner:** Peter Higgins · Rogue Wave Audio · Markham, Ontario
**Framework:** HUF v1.2.0 · MIT License

---

## What this package is

This is the complete governance scaffolding for the Higgins Unity Framework (HUF) document library.
It encodes the rules, structures, and contracts that prevent:

- **Naming collisions** — multiple agents producing "primer.md", "exhibit.docx", "taxonomy.md" with identical filenames
- **Silent overwrites** — new versions replacing old without an auditable supersession chain
- **Tool takeover** — AI systems accumulating decision authority beyond the declared operator cap
- **Canonical drift** — "which version is real?" becoming unanswerable

The governing principle, applied to the library itself:

> **Nothing disappears silently. The operator remains in command.**

---

## How to use this package (minimum steps)

1. Read `01_SYSTEM_OVERVIEW.md` — the coding system, header format, and lane rules
2. Read `02_OPERATOR_CONTROL_CONTRACT.md` — the 51/49 rule and working contract
3. Read `03_VOLUME_PLAN.md` — the 8-volume structure for the full corpus
4. Use `04_CLAUDE_ONBOARDING_CHECKLIST.md` — the step-by-step sorting plan for a new Claude session
5. Update `notes/_org/doc_manifest.json` as documents are promoted
6. Use `notes/_org/sitemap.json` to navigate the library

---

## File index

| File | Role |
|------|------|
| 01_SYSTEM_OVERVIEW.md | Document coding system — the "HUF Document 1" |
| 02_OPERATOR_CONTROL_CONTRACT.md | HUF-51/49 and working contract example |
| 03_VOLUME_PLAN.md | 8-volume corpus structure |
| 04_CLAUDE_ONBOARDING_CHECKLIST.md | Step-by-step sorting plan |
| notes/_org/doc_governance.md | Full governance rules |
| notes/_org/ai_use_standard.md | AI use posture (one-page insert) |
| notes/_org/doc_id_registry.json | Doc ID format, presets, issued IDs |
| notes/_org/doc_manifest.json | Inventory of all 25 known corpus files |
| notes/_org/sitemap.json | Human navigation map |
| notes/_org/templates/header_md.txt | Two-line header template (Markdown) |
| notes/_org/templates/header_docx.txt | Two-line header template (DOCX/PDF) |
| notes/_org/templates/working_contract.md | HUF Working Contract template |

---

## Claude cover note (paste when sending this zip)

> This package is governance scaffolding for the HUF corpus. The collective is now
> producing outputs with overlapping filenames and we need a document system before
> collisions become unrecoverable.
>
> The goal is to treat the documentation library as a HUF-governed system itself:
> Doc IDs are stable identities (regime labels). The manifest is the trace report.
> The sitemap is the coherence map. The operator-control contract (HUF-51/49) ensures
> tools cannot accumulate majority decision authority.
>
> Please use the checklist in 04_CLAUDE_ONBOARDING_CHECKLIST.md to:
> 1. Produce a collision report
> 2. Assign Doc IDs to all "real" documents
> 3. Update the manifest and sitemap
> 4. Propose volume assignments (do not move files; propose only)
> 5. Flag the top 5 drift/risk points you see
>
> Constraints: do not delete files; preserve legacy trail;
> OP >= 0.51 always; release gates remain human-only.
>
> — Peter Higgins · Rogue Wave Audio
