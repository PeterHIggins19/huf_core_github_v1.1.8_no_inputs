HUF-DOC: HUF.REL.ORG.CONTRACT.OPERATOR_CONTROL | HUF:1.2.0 | DOC:v1.0.0 | STATUS:release | LANE:REL | RO:Peter Higgins
CODES: ORG, GOVERNANCE, SAFETY, OPERATOR_CONTROL | ART: CM, AS, TR, EB | EVID:E1 | POSTURE:OP | WEIGHTS: OP=0.80 TOOL=0.20 PEER=0.00 | CAP: OP_MIN=0.51 TOOL_MAX=0.49 | CANON:02_OPERATOR_CONTROL_CONTRACT.md

# HUF Operator Control Contract
## The 51/49 Rule — Protecting the Operator from Tool Takeover
*HUF v1.2.0 · 2026-03-01 · Peter Higgins · Rogue Wave Audio*

---

## 1. The core principle

> **The tool must never control the operator.**
> A HUF operator is always the majority decision-holder in any HUF-governed workflow.
> This is not a recommendation. It is a hard structural constraint.

HUF is a governance instrument for finite-budget systems. It detects when declared allocation
drifts from observed allocation — silently or intentionally. That instrument is powerful.
A powerful instrument can itself become a governance risk if its outputs accumulate authority
that properly belongs to the operator.

The Operator Control Contract is HUF applied to itself:
the operator's share of the governance portfolio must never fall below 51%.

---

## 2. Why this is the right structural limit

### 2.1 The reflexive argument

HUF treats any finite-budget system as governable by the unity constraint.
The operator/tool relationship is a finite-budget system:
- Budget: total decision authority (attention, review weight, release approval)
- Elements: Operator (OP), Tool (TOOL), Peer reviewers (PEER)
- Constraint: OP + TOOL + PEER = 1.0

If the unity constraint applies here — and it does — then silent drift from declared operator
authority is exactly the failure mode HUF is designed to detect and prevent.
The Operator Control Contract makes that drift structurally impossible, not just monitorable.

### 2.2 The structural minimum analogy

Crna Mlaka holds 0.91% of Croatia's Ramsar portfolio. Its governance leverage is 110.
Nobody decided to reduce its monitoring share — it drifted silently.

The operator is the Crna Mlaka of the governance system:
small in absolute terms when surrounded by high-throughput AI tools,
but critically non-substitutable. When operator share falls below the minimum viable threshold,
the system loses its governance anchor. The tool becomes the de-facto decision-maker —
not by declaration, but by silent drift.

The 51% floor is the minimum viable operator share. Below it, the system is no longer
HUF-governed. It is tool-governed, which is the failure mode the framework exists to prevent.

### 2.3 Why 51% and not 60% or 70%?

The 51% threshold is a hard floor, not a target. Targets are maturity presets.

The floor is set at 51% because:
- It preserves human majority in any weighted readiness decision
- It allows maximum tool contribution (49%) for operators with high tool trust
- It maps naturally to the democratic majority principle: the operator never loses the vote
- It is numerically clean and auditable: a single number, not a range

The 51% floor can never be negotiated below. The maturity presets determine where
operators actually operate within the range [0.51, 1.00].

### 2.4 The maturity scale

Tool trust is earned, not assumed. The scale reflects how trust accumulates:

| Maturity level | OP weight | TOOL weight | PEER weight | When to use |
|----------------|-----------|-------------|-------------|-------------|
| Beginner | 0.80 | 0.20 | 0.00 | First HUF deployment; unfamiliar AI tools; high-stakes output |
| Standard team | 0.65 | 0.20 | 0.15 | Established workflow; peer review present |
| Trusted tool (experimental) | 0.51 | 0.49 | 0.00 | Many iterations; traced decisions; operator explicitly opts in |

Movement between levels requires:
- At least 3 completed cycles with trace records
- Explicit operator declaration in the header (WEIGHTS field)
- No recent uncorrected silent drift events

---

## 3. What weights apply to (and what they do not)

### Weights apply to:
- **Draft readiness scoring** — the weighted average of operator review score (R_OP),
  tool readiness score (R_TOOL), and peer score (R_PEER):

  `R = w_OP · R_OP + w_TOOL · R_TOOL + w_PEER · R_PEER`

  If R >= threshold (e.g., 0.80), the document proceeds to release consideration.

### Weights do NOT apply to:
- **Release / publish / send / merge / commit** — these are ALWAYS human-only gates
- The operator cannot delegate the release decision to a weighted score
- No auto-commit, no auto-publish, no "AI decided"

This mirrors the HUF distinction between monitoring (continuous, weighted) and governance
decisions (event-triggered, human-declared). The readiness score monitors. The release gate decides.

---

## 4. The operator is subject to HUF compliance

To be a HUF-compliant operator, you must:

1. **Declare weights** in the document header (WEIGHTS field)
2. **Maintain the hard cap** (OP >= 0.51, TOOL <= 0.49)
3. **Name the Responsible Operator** (RO field in line 1)
4. **Keep a trace record** of significant decisions (what changed, why, who decided)
5. **Apply the supersession rule** — no silent overwrites

A document that lacks declared weights is not HUF-compliant.
A document that declares OP < 0.51 is not HUF-compliant.
A document without a named RO is not HUF-compliant.

Non-compliance means the document cannot be audited — and HUF's core value proposition
is auditability. A governance instrument that cannot audit itself is not functioning.

---

## 5. HUF Working Contract — example

This is the canonical working contract for the HUF collective.
It is embedded in the manifest (compliance fields) and referenced in every document header.

```
───────────────────────────────────────────────────────────
HUF WORKING CONTRACT
───────────────────────────────────────────────────────────
Contract ID:     HUF.REL.ORG.CONTRACT.OPERATOR_CONTROL
HUF Version:     1.2.0
Date:            2026-03-01

PARTIES
Responsible Operator (RO): Peter Higgins · Rogue Wave Audio · Markham, Ontario
Tools (collective):        Claude · ChatGPT · Grok · Gemini · Copilot

SCOPE
Documentation + research workflow for the Higgins Unity Framework.
Applies to: all documents, case studies, outreach materials, and code
produced within the HUF corpus.

DECLARED WEIGHTS (readiness review)
w_OP   = 0.51   (Responsible Operator — minimum compliant)
w_TOOL = 0.49   (collective AI tools — maximum allowed)
w_PEER = 0.00   (no external peer review at this stage)

HARD CAPS (invariant — cannot be overridden)
OP_MIN  = 0.51  (operator must always hold majority)
TOOL_MAX = 0.49 (tool influence is capped at minority)

READINESS SCORING FORMULA
R = w_OP · R_OP + w_TOOL · R_TOOL + w_PEER · R_PEER
Threshold for release consideration: R >= 0.80

RELEASE GATE (human-only — not subject to weighting)
Release / publish / send / commit requires explicit operator approval.
No automated publication. No AI-initiated dispatch.

COMPLIANCE CHECKS (per document)
[ ] Weights declared in header (WEIGHTS field)
[ ] Caps satisfied (OP >= 0.51, TOOL <= 0.49)
[ ] RO named (RO field in line 1)
[ ] Supersession chain present (if replacing prior document)
[ ] Trace record attached or referenced

NON-COMPLIANCE CONSEQUENCE
Document remains in STAGED lane.
Cannot be promoted to RELEASE until all checks pass.
───────────────────────────────────────────────────────────
```

---

## 6. Beginner-mode working contract (recommended for new HUF deployments)

For operators who are new to HUF or deploying in a new domain:

```
───────────────────────────────────────────────────────────
HUF WORKING CONTRACT — BEGINNER MODE
───────────────────────────────────────────────────────────
w_OP   = 0.80   (operator carries most review weight)
w_TOOL = 0.20   (tool contribution is advisory)
w_PEER = 0.00

Hard caps: OP_MIN=0.51 TOOL_MAX=0.49 (same for all maturity levels)

When to upgrade from beginner mode:
- At least 5 completed document cycles with trace records
- No uncorrected silent drift in the last 3 cycles
- Operator explicitly declares maturity upgrade in the governance log
───────────────────────────────────────────────────────────
```

---

## 7. Compliance monitoring

HUF monitors its own operator-control compliance using the same instrument
it uses for all finite-budget systems:

| Metric | HUF expression | Operator-control expression |
|--------|---------------|----------------------------|
| Portfolio share | ρ_i = share_i / Σ share | ρ_OP = w_OP / 1.0 |
| Minimum viable share | Orphan alert when ρ < threshold | Noncompliant when w_OP < 0.51 |
| Leverage | L = 1 / ρ | L_OP = 1 / w_OP (high leverage = high governance risk) |
| Drift detection | Gap = declared − observed | Declared OP weight vs. actual review involvement |
| Ground state | MDG → 0 | All decisions declared; no undocumented tool overrides |

At w_OP = 0.51, operator leverage = 1.96 — still majority, low leverage.
At w_OP = 0.20 (non-compliant), operator leverage = 5.0 — minority, high governance risk.
At w_OP = 0.10 (severely non-compliant), operator leverage = 10.0 — the tool is the de-facto governor.

---

## 8. Application to new HUF deployments

When a new organization or individual deploys HUF:

1. They are the Responsible Operator for their deployment
2. They must declare weights appropriate to their maturity level
3. They MUST start at or above OP=0.80 for first deployment
4. They may not set OP below 0.51 under any circumstances
5. Release gates remain human-only regardless of declared weights

This applies whether the deployment is:
- An EMS company using HUF for Fuji NXTR placement governance
- A Ramsar Contracting Party using HUF for portfolio monitoring
- A software team using HUF for retrieval pipeline governance
- An individual researcher using HUF for document library management

---

*Peter Higgins · Rogue Wave Audio · Markham, Ontario*
*HUF v1.2.0 · MIT License · 2026-03-01*
*Developed in collective with: Claude, ChatGPT, Grok, Gemini, Copilot*
