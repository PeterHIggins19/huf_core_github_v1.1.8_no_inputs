HUF-DOC: HUF.REL.ORG.NOTE.CLAUDE_ONBOARDING | HUF:1.2.0 | DOC:v1.0.0 | STATUS:release | LANE:REL | RO:Peter Higgins
CODES: ORG, PROCESS, AI_ONBOARDING | ART: TR | EVID:E1 | POSTURE:OP | WEIGHTS: OP=0.80 TOOL=0.20 PEER=0.00 | CAP: OP_MIN=0.51 TOOL_MAX=0.49 | CANON:04_CLAUDE_ONBOARDING_CHECKLIST.md

# Claude Onboarding Checklist
## Step-by-step corpus organization plan for a new Claude session
*HUF v1.2.0 · 2026-03-01*

---

## Before you start: read first

1. `01_SYSTEM_OVERVIEW.md` — the full coding and header system
2. `02_OPERATOR_CONTROL_CONTRACT.md` — the 51/49 rule and working contract
3. `03_VOLUME_PLAN.md` — what goes in each volume

---

## Constraints (invariant — do not override)

- **Do not delete any file.** Every file goes to legacy lane if superseded; none are removed.
- **Anything without a two-line header is INBOX** until explicitly tagged.
- **OP >= 0.51 in all declared weights.** Any document declaring OP < 0.51 is noncompliant.
- **Release gates are human-only.** You propose; Peter decides.
- **Conservative posture discipline:**
  - Prefer "structural invariance (interpretive)" over "domain-invariant"
  - Reserve "theorem" for results with explicit stated assumptions + complete proof
  - Use [PROVED] / [CONJECTURE] / [CONJECTURAL] markers in any math document

---

## Phase 0 — Safety (do first)

- Confirm legacy folder exists: `notes/legacy/`
- Confirm inbox folder exists: `notes/current_documents/inbox/YYYY-MM/`
- Do not move or rename any existing file until inventory is complete

---

## Phase 1 — Inventory

### Step 1.1 — List all documents
Scan all files in the corpus. Produce a table:
| Filename | Size | Date | Has two-line header? | Collision risk? |

### Step 1.2 — Identify collision clusters
Flag any cluster where 2+ documents have similar names or titles (e.g., multiple "primer" or "exhibit" files).
For each cluster: identify which is most recent and most complete.

### Step 1.3 — Assign Doc IDs
For every document that should be tracked (not just inbox material):
- Assign a Doc ID using format: `HUF.<LANE>.<DOMAIN>.<TYPE>.<SLUG>`
- Record in manifest

**Deliverable:** Updated `notes/_org/doc_manifest.json` with:
`doc_id, title, canonical_path, status, lane, supersedes, updated`

---

## Phase 2 — Canonical selection

### Step 2.1 — Choose canonical for each cluster
For each collision cluster:
- Designate one document as canonical
- Mark others as deprecated with `superseded_by` pointing to canonical

### Step 2.2 — Apply two-line headers
Add the two-line header to each canonical document (as a first-block insert for DOCX).
Add to each deprecated/legacy document as well (with STATUS:deprecated).

**Deliverable:** All "real" documents have two-line headers; supersession chain is complete.

---

## Phase 3 — Volume assignment

### Step 3.1 — Tag each canonical document
For each canonical document, assign:
- `volume`: 1 through 8
- `domain`: ORG / LRN / BOOK / CASE / PARTNER / WIKI
- `type`: POLICY / NOTE / EXHIBIT / PRIMER / TRACE / etc.

**Reference:** see Volume Plan (03_VOLUME_PLAN.md) for volume definitions and known file assignments.

### Step 3.2 — Propose stable homes (do not move files)
For each canonical document, state the proposed stable path:
- `docs/books/vol_2_handbook/` for handbook
- `cases/croatia_ramsar/` for Croatia pilot files
- `notes/_org/` for governance files

**Deliverable:** Volume table — Volume → Canonical doc IDs → Proposed paths.

---

## Phase 4 — Cohesion pass

### Step 4.1 — Vocabulary audit
Check for inconsistent terminology across documents:
- "allocation change log" should be "Portfolio change log"
- "dropped attention record" should be "Coverage change record"
- "domain-invariant" should be "structural invariance (interpretive)" unless proof is complete
- "Hierarchical Unity Framework" in any document → flag for name resolution (should be "Higgins Unity Framework")

### Step 4.2 — Proof posture audit
In any math document, check for:
- Claims stated without [PROVED] / [CONJECTURE] markers
- Leverage described as "precise multiplier" without the qualifying note
- Theorems stated without explicit assumptions

**Deliverable:** Cohesion report — list of vocabulary and posture issues with specific file + line references.

---

## Phase 5 — Risk report

Identify the top 5 risks or drift points in the current corpus. Suggested format:
| Risk | Files affected | Consequence | Recommended action |

**Suggested risk categories:**
- Canonical ambiguity (two files compete for same role)
- Proof posture inconsistency (claims vary across documents)
- Blocked item dependencies (D7, D8, D9 chain)
- AI contribution attribution gaps (which AI contributed which section)
- Framework name inconsistency (Hierarchical vs. Higgins)

---

## Deliverable summary

| Deliverable | Format | Priority |
|------------|--------|---------|
| Collision report | Markdown table | First |
| Updated manifest (doc_id + status + volume) | JSON file | First |
| Volume assignment table | Markdown table | Second |
| Proposed canonical paths | Markdown list | Second |
| Cohesion report | Markdown | Third |
| Top 5 risk report | Markdown table | Third |

---

*This checklist is self-applying: it follows the HUF-51/49 contract.*
*All outputs from Claude are advisory; Peter approves before any file moves.*
*Peter Higgins · Rogue Wave Audio · 2026-03-01*
